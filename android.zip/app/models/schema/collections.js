let configsDatabase = {
    COL_MENUS: 'tt_menus'
};

module.exports = Object.freeze(configsDatabase);