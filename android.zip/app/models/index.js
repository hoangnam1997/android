module.exports = {
    menu: require('./menu'),
};
