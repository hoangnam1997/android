module.exports = {
    menu: require('./menu'),
    home: require('./home'),
    detail: require('./detail'),
};
