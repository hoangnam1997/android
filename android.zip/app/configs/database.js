let configsDatabase = {
    database: 'mongodb://trucvip:truccuibap123@103.68.68.151:27017/m01?authMechanism=SCRAM-SHA-1',
};

module.exports = Object.freeze(configsDatabase);