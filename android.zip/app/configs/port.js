let configsPort = {
    PORT_65014: 65014, //app
};

module.exports = Object.freeze(configsPort);
